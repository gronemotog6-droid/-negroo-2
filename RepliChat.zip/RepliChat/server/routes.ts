import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { OpenAIService } from "./services/openai";
import { GeminiService } from "./services/gemini";
import { ElevenLabsService } from "./services/elevenlabs";
import { insertCharacterSchema, insertConversationSchema, insertMessageSchema, insertApiKeySchema, loginSchema, insertVoiceCallSchema } from "@shared/schema";

interface ClientConnection {
  ws: WebSocket;
  userId?: string;
  conversationId?: string;
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  const clients = new Map<string, ClientConnection>();

  // WebSocket handling for real-time chat
  wss.on('connection', (ws) => {
    const clientId = Math.random().toString(36).substring(7);
    clients.set(clientId, { ws });

    ws.on('message', async (data) => {
      try {
        const message = JSON.parse(data.toString());
        const client = clients.get(clientId);
        
        if (message.type === 'join-conversation') {
          if (client) {
            client.conversationId = message.conversationId;
            client.userId = message.userId;
          }
        }
        
        if (message.type === 'send-message') {
          await handleChatMessage(message, clientId);
        }

        if (message.type === 'start-voice-call') {
          await handleVoiceCallStart(message, clientId);
        }

        if (message.type === 'end-voice-call') {
          await handleVoiceCallEnd(message, clientId);
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });

    ws.on('close', () => {
      clients.delete(clientId);
    });
  });

  async function handleChatMessage(message: any, clientId: string) {
    const client = clients.get(clientId);
    if (!client || !client.conversationId || !client.userId) return;

    try {
      // Save user message
      const userMessage = await storage.createMessage({
        conversationId: client.conversationId,
        role: 'user',
        content: message.content,
      });

      // Broadcast user message to all clients in the conversation
      broadcastToConversation(client.conversationId, {
        type: 'new-message',
        message: userMessage,
      });

      // Get conversation and character info
      const conversation = await storage.getConversation(client.conversationId);
      if (!conversation) return;

      const character = await storage.getCharacter(conversation.characterId);
      if (!character) return;

      // Get recent messages for context
      const recentMessages = await storage.getMessages(client.conversationId);
      const contextMessages = recentMessages.slice(-10).map(msg => ({
        role: msg.role as 'user' | 'assistant',
        content: msg.content,
      }));

      // Get user's API key for the character's AI provider
      const apiKey = await storage.getUserApiKey(client.userId, character.aiProvider);
      if (!apiKey) {
        throw new Error(`API key not configured for ${character.aiProvider}`);
      }

      // Generate AI response
      let aiResponse: string;
      if (character.aiProvider === 'openai') {
        const openaiService = new OpenAIService(apiKey.keyValue);
        aiResponse = await openaiService.generateResponse(
          character.personality,
          contextMessages,
          character.model
        );
      } else if (character.aiProvider === 'gemini') {
        const geminiService = new GeminiService(apiKey.keyValue);
        aiResponse = await geminiService.generateResponse(
          character.personality,
          contextMessages,
          character.model
        );
      } else {
        throw new Error('Unsupported AI provider');
      }

      // Save AI message
      const aiMessage = await storage.createMessage({
        conversationId: client.conversationId,
        role: 'assistant',
        content: aiResponse,
      });

      // Generate audio if ElevenLabs is configured and character has voiceId
      if (character.voiceId) {
        const elevenLabsKey = await storage.getUserApiKey(client.userId, 'elevenlabs');
        if (elevenLabsKey) {
          try {
            const elevenLabs = new ElevenLabsService(elevenLabsKey.keyValue);
            const audioBuffer = await elevenLabs.generateSpeech(aiResponse, character.voiceId);
            
            // In a real implementation, you'd save this to cloud storage and get a URL
            // For now, we'll just indicate that audio is available
            aiMessage.audioUrl = `data:audio/mpeg;base64,${audioBuffer.toString('base64')}`;
          } catch (error) {
            console.error('Audio generation error:', error);
          }
        }
      }

      // Broadcast AI response
      broadcastToConversation(client.conversationId, {
        type: 'new-message',
        message: aiMessage,
      });

    } catch (error) {
      console.error('Chat message handling error:', error);
      
      // Send error message to client
      if (client.ws.readyState === WebSocket.OPEN) {
        client.ws.send(JSON.stringify({
          type: 'error',
          message: error instanceof Error ? error.message : 'Error al generar respuesta',
        }));
      }
    }
  }

  function broadcastToConversation(conversationId: string, data: any) {
    clients.forEach((client) => {
      if (client.conversationId === conversationId && client.ws.readyState === WebSocket.OPEN) {
        client.ws.send(JSON.stringify(data));
      }
    });
  }

  // REST API Routes

  // Characters
  app.get('/api/characters', async (req, res) => {
    try {
      const characters = await storage.getCharacters();
      res.json(characters);
    } catch (error) {
      res.status(500).json({ message: 'Error al obtener personajes' });
    }
  });

  app.get('/api/characters/:id', async (req, res) => {
    try {
      const character = await storage.getCharacter(req.params.id);
      if (!character) {
        return res.status(404).json({ message: 'Personaje no encontrado' });
      }
      res.json(character);
    } catch (error) {
      res.status(500).json({ message: 'Error al obtener personaje' });
    }
  });

  app.post('/api/characters', async (req, res) => {
    try {
      const characterData = insertCharacterSchema.parse(req.body);
      const character = await storage.createCharacter({
        ...characterData,
        createdBy: req.body.userId || 'anonymous', // In a real app, get from session
      });
      res.json(character);
    } catch (error) {
      res.status(400).json({ message: 'Datos de personaje inválidos' });
    }
  });

  // Conversations
  app.get('/api/conversations', async (req, res) => {
    try {
      const userId = req.query.userId as string;
      if (!userId) {
        return res.status(400).json({ message: 'userId requerido' });
      }
      
      const conversations = await storage.getUserConversations(userId);
      
      // Get character info and recent messages for each conversation
      const conversationsWithDetails = await Promise.all(
        conversations.map(async (conv) => {
          const character = await storage.getCharacter(conv.characterId);
          const messages = await storage.getMessages(conv.id);
          const lastMessage = messages[messages.length - 1];
          
          return {
            ...conv,
            character,
            lastMessage,
            messageCount: messages.length,
          };
        })
      );
      
      res.json(conversationsWithDetails);
    } catch (error) {
      res.status(500).json({ message: 'Error al obtener conversaciones' });
    }
  });

  app.post('/api/conversations', async (req, res) => {
    try {
      const conversationData = insertConversationSchema.parse(req.body);
      const conversation = await storage.createConversation({
        ...conversationData,
        userId: req.body.userId || 'anonymous', // In a real app, get from session
      });
      res.json(conversation);
    } catch (error) {
      res.status(400).json({ message: 'Datos de conversación inválidos' });
    }
  });

  app.delete('/api/conversations/:id/messages', async (req, res) => {
    try {
      await storage.deleteMessages(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: 'Error al limpiar conversación' });
    }
  });

  // Messages
  app.get('/api/conversations/:id/messages', async (req, res) => {
    try {
      const messages = await storage.getMessages(req.params.id);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: 'Error al obtener mensajes' });
    }
  });

  // API Keys
  app.get('/api/api-keys', async (req, res) => {
    try {
      const userId = req.query.userId as string;
      if (!userId) {
        return res.status(400).json({ message: 'userId requerido' });
      }
      
      const apiKeys = await storage.getUserApiKeys(userId);
      
      // Don't expose the actual key values
      const safeApiKeys = apiKeys.map(key => ({
        ...key,
        keyValue: key.keyValue ? '***' + key.keyValue.slice(-4) : '',
        hasKey: !!key.keyValue,
      }));
      
      res.json(safeApiKeys);
    } catch (error) {
      res.status(500).json({ message: 'Error al obtener API keys' });
    }
  });

  app.post('/api/api-keys', async (req, res) => {
    try {
      const apiKeyData = insertApiKeySchema.parse(req.body);
      
      // Test the API key before saving
      let isValid = false;
      try {
        if (apiKeyData.provider === 'openai') {
          const service = new OpenAIService(apiKeyData.keyValue);
          isValid = await service.testConnection();
        } else if (apiKeyData.provider === 'gemini') {
          const service = new GeminiService(apiKeyData.keyValue);
          isValid = await service.testConnection();
        } else if (apiKeyData.provider === 'elevenlabs') {
          const service = new ElevenLabsService(apiKeyData.keyValue);
          isValid = await service.testConnection();
        }
      } catch (error) {
        console.error('API key validation error:', error);
      }

      if (!isValid) {
        return res.status(400).json({ message: 'API key inválida o no funcional' });
      }

      const apiKey = await storage.createApiKey({
        ...apiKeyData,
        userId: req.body.userId || 'anonymous', // In a real app, get from session
      });
      
      res.json({
        ...apiKey,
        keyValue: '***' + apiKey.keyValue.slice(-4),
      });
    } catch (error) {
      res.status(400).json({ message: 'Datos de API key inválidos' });
    }
  });

  app.delete('/api/api-keys/:id', async (req, res) => {
    try {
      await storage.deleteApiKey(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: 'Error al eliminar API key' });
    }
  });

  // Voice call handlers
  async function handleVoiceCallStart(message: any, clientId: string) {
    try {
      const client = clients.get(clientId);
      if (!client?.userId || !client?.conversationId) return;

      const voiceCall = await storage.createVoiceCall({
        conversationId: client.conversationId,
        userId: client.userId,
        status: 'connecting',
      });

      // Update voice call to active
      await storage.updateVoiceCall(voiceCall.id, { status: 'active' });

      // Notify all clients in the conversation
      clients.forEach((c) => {
        if (c.conversationId === client.conversationId && c.ws.readyState === WebSocket.OPEN) {
          c.ws.send(JSON.stringify({
            type: 'voice-call-started',
            voiceCallId: voiceCall.id,
            status: 'active'
          }));
        }
      });
    } catch (error) {
      console.error('Voice call start error:', error);
    }
  }

  async function handleVoiceCallEnd(message: any, clientId: string) {
    try {
      const client = clients.get(clientId);
      if (!client?.conversationId) return;

      const voiceCall = await storage.getVoiceCall(client.conversationId);
      if (voiceCall) {
        await storage.endVoiceCall(voiceCall.id);

        // Notify all clients in the conversation
        clients.forEach((c) => {
          if (c.conversationId === client.conversationId && c.ws.readyState === WebSocket.OPEN) {
            c.ws.send(JSON.stringify({
              type: 'voice-call-ended',
              voiceCallId: voiceCall.id,
              duration: voiceCall.duration
            }));
          }
        });
      }
    } catch (error) {
      console.error('Voice call end error:', error);
    }
  }

  // Authentication routes
  app.post("/api/auth/login", async (req, res) => {
    try {
      const loginData = loginSchema.parse(req.body);
      const user = await storage.authenticateUser(loginData.username, loginData.password);
      
      if (!user) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      // Store user session
      req.session!.userId = user.id;
      req.session!.isAdmin = user.isAdmin;

      res.json({ 
        user: { 
          id: user.id, 
          username: user.username, 
          isAdmin: user.isAdmin 
        } 
      });
    } catch (error) {
      res.status(400).json({ error: "Invalid request data" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session?.destroy((err) => {
      if (err) {
        return res.status(500).json({ error: "Failed to logout" });
      }
      res.json({ success: true });
    });
  });

  app.get("/api/auth/me", (req, res) => {
    if (!req.session?.userId) {
      return res.status(401).json({ error: "Not authenticated" });
    }

    res.json({
      userId: req.session.userId,
      isAdmin: req.session.isAdmin || false
    });
  });

  // Voice call routes
  app.get("/api/voice-calls/:conversationId", async (req, res) => {
    try {
      const { conversationId } = req.params;
      const voiceCall = await storage.getVoiceCall(conversationId);
      
      if (!voiceCall) {
        return res.status(404).json({ error: "Voice call not found" });
      }

      res.json(voiceCall);
    } catch (error) {
      res.status(500).json({ error: "Failed to get voice call" });
    }
  });

  return httpServer;
}
