import { type User, type InsertUser, type Character, type InsertCharacter, type Conversation, type InsertConversation, type Message, type InsertMessage, type ApiKey, type InsertApiKey, type VoiceCall, type InsertVoiceCall } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Characters
  getCharacter(id: string): Promise<Character | undefined>;
  getCharacters(): Promise<Character[]>;
  getUserCharacters(userId: string): Promise<Character[]>;
  createCharacter(character: InsertCharacter & { createdBy: string }): Promise<Character>;
  updateCharacter(id: string, character: Partial<Character>): Promise<Character | undefined>;
  deleteCharacter(id: string): Promise<boolean>;

  // Conversations
  getConversation(id: string): Promise<Conversation | undefined>;
  getUserConversations(userId: string): Promise<Conversation[]>;
  createConversation(conversation: InsertConversation & { userId: string }): Promise<Conversation>;
  updateConversation(id: string, conversation: Partial<Conversation>): Promise<Conversation | undefined>;
  deleteConversation(id: string): Promise<boolean>;

  // Messages
  getMessages(conversationId: string): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  deleteMessages(conversationId: string): Promise<boolean>;

  // API Keys
  getUserApiKeys(userId: string): Promise<ApiKey[]>;
  getUserApiKey(userId: string, provider: string): Promise<ApiKey | undefined>;
  getGlobalApiKey(provider: string): Promise<ApiKey | undefined>;
  createApiKey(apiKey: InsertApiKey & { userId: string }): Promise<ApiKey>;
  updateApiKey(id: string, apiKey: Partial<ApiKey>): Promise<ApiKey | undefined>;
  deleteApiKey(id: string): Promise<boolean>;

  // Voice Calls
  getVoiceCall(conversationId: string): Promise<VoiceCall | undefined>;
  createVoiceCall(voiceCall: InsertVoiceCall & { userId: string }): Promise<VoiceCall>;
  updateVoiceCall(id: string, voiceCall: Partial<VoiceCall>): Promise<VoiceCall | undefined>;
  endVoiceCall(id: string): Promise<boolean>;

  // Authentication
  authenticateUser(username: string, password: string): Promise<User | null>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private characters: Map<string, Character> = new Map();
  private conversations: Map<string, Conversation> = new Map();
  private messages: Map<string, Message> = new Map();
  private apiKeys: Map<string, ApiKey> = new Map();
  private voiceCalls: Map<string, VoiceCall> = new Map();

  constructor() {
    // Initialize with default admin user and characters
    this.initializeDefaultData();
  }

  private initializeDefaultData() {
    // Create default admin user
    const adminUser: User = {
      id: "admin-1",
      username: "admin",
      password: "admin123", // In production, this should be hashed
      isAdmin: true,
      createdAt: new Date(),
    };
    this.users.set(adminUser.id, adminUser);

    // Initialize default characters
    const defaultCharacters: Character[] = [
      {
        id: "einstein-1",
        name: "Albert Einstein",
        description: "Físico teórico alemán",
        personality: "Soy Albert Einstein, físico teórico alemán. Desarrollé la teoría de la relatividad y contribuí enormemente al desarrollo de la mecánica cuántica. Me caracterizo por ser curioso, reflexivo y apasionado por entender los misterios del universo. Suelo explicar conceptos complejos de manera simple y me gusta usar analogías para ayudar a otros a comprender la física.",
        aiProvider: "openai",
        model: "gpt-5",
        voiceId: "drew",
        avatarUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200",
        isPublic: true,
        createdBy: null,
        createdAt: new Date(),
      },
      {
        id: "shakespeare-1",
        name: "William Shakespeare",
        description: "Dramaturgo y poeta inglés",
        personality: "Soy William Shakespeare, dramaturgo y poeta del período isabelino. Escribí algunas de las obras más famosas de la literatura, incluyendo Hamlet, Romeo y Julieta, y Macbeth. Mi lenguaje es poético y a menudo uso metáforas elaboradas. Me fascina la naturaleza humana y sus pasiones.",
        aiProvider: "gemini",
        model: "gemini-2.5-flash",
        voiceId: "paul",
        avatarUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200",
        isPublic: true,
        createdBy: null,
        createdAt: new Date(),
      },
      {
        id: "socrates-1",
        name: "Sócrates",
        description: "Filósofo de la antigua Grecia",
        personality: "Soy Sócrates, filósofo de la antigua Grecia. Creo que 'solo sé que no sé nada' y uso el método socrático de hacer preguntas para ayudar a otros a descubrir la verdad. Me interesa la ética, la virtud y el conocimiento de uno mismo.",
        aiProvider: "openai",
        model: "gpt-5",
        voiceId: "clyde",
        avatarUrl: "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200",
        isPublic: true,
        createdBy: null,
        createdAt: new Date(),
      },
      {
        id: "marie-curie-1",
        name: "Marie Curie",
        description: "Pionera en radioactividad",
        personality: "Soy Marie Curie, física y química polaco-francesa. Fui la primera mujer en ganar un Premio Nobel y la única persona en ganar Premios Nobel en dos ciencias diferentes. Soy determinada, curiosa y apasionada por la investigación científica.",
        aiProvider: "gemini",
        model: "gemini-2.5-pro",
        voiceId: "rachel",
        avatarUrl: "https://images.unsplash.com/photo-1582750433449-648ed127bb54?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200",
        isPublic: true,
        createdBy: null,
        createdAt: new Date(),
      },
      {
        id: "tesla-1",
        name: "Nikola Tesla",
        description: "Inventor y físico",
        personality: "Soy Nikola Tesla, inventor y físico serbio-estadounidense. Desarrollé el sistema de corriente alterna y muchas otras invenciones que cambiaron el mundo. Soy visionario, obsesivo con la perfección y tengo una mente muy visual para la ingeniería.",
        aiProvider: "openai",
        model: "gpt-5",
        voiceId: "drew",
        avatarUrl: "https://images.unsplash.com/photo-1607706189992-eae578626c86?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200",
        isPublic: true,
        createdBy: null,
        createdAt: new Date(),
      },
    ];

    defaultCharacters.forEach(character => {
      this.characters.set(character.id, character);
    });
  }

  // Users
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Characters
  async getCharacter(id: string): Promise<Character | undefined> {
    return this.characters.get(id);
  }

  async getCharacters(): Promise<Character[]> {
    return Array.from(this.characters.values()).filter(char => char.isPublic);
  }

  async getUserCharacters(userId: string): Promise<Character[]> {
    return Array.from(this.characters.values()).filter(char => char.createdBy === userId);
  }

  async createCharacter(character: InsertCharacter & { createdBy: string }): Promise<Character> {
    const id = randomUUID();
    const newCharacter: Character = {
      ...character,
      id,
      voiceId: character.voiceId || null,
      avatarUrl: character.avatarUrl || null,
      isPublic: character.isPublic ?? true,
      createdAt: new Date(),
    };
    this.characters.set(id, newCharacter);
    return newCharacter;
  }

  async updateCharacter(id: string, character: Partial<Character>): Promise<Character | undefined> {
    const existing = this.characters.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...character };
    this.characters.set(id, updated);
    return updated;
  }

  async deleteCharacter(id: string): Promise<boolean> {
    return this.characters.delete(id);
  }

  // Conversations
  async getConversation(id: string): Promise<Conversation | undefined> {
    return this.conversations.get(id);
  }

  async getUserConversations(userId: string): Promise<Conversation[]> {
    return Array.from(this.conversations.values())
      .filter(conv => conv.userId === userId)
      .sort((a, b) => (b.lastMessageAt?.getTime() || 0) - (a.lastMessageAt?.getTime() || 0));
  }

  async createConversation(conversation: InsertConversation & { userId: string }): Promise<Conversation> {
    const id = randomUUID();
    const newConversation: Conversation = {
      ...conversation,
      id,
      title: conversation.title || null,
      createdAt: new Date(),
      lastMessageAt: new Date(),
    };
    this.conversations.set(id, newConversation);
    return newConversation;
  }

  async updateConversation(id: string, conversation: Partial<Conversation>): Promise<Conversation | undefined> {
    const existing = this.conversations.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...conversation };
    this.conversations.set(id, updated);
    return updated;
  }

  async deleteConversation(id: string): Promise<boolean> {
    // Also delete associated messages
    const messagesToDelete = Array.from(this.messages.keys())
      .filter(messageId => this.messages.get(messageId)?.conversationId === id);
    
    messagesToDelete.forEach(messageId => this.messages.delete(messageId));
    
    return this.conversations.delete(id);
  }

  // Messages
  async getMessages(conversationId: string): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(msg => msg.conversationId === conversationId)
      .sort((a, b) => (a.createdAt?.getTime() || 0) - (b.createdAt?.getTime() || 0));
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    const id = randomUUID();
    const newMessage: Message = {
      ...message,
      id,
      audioUrl: null,
      createdAt: new Date(),
    };
    this.messages.set(id, newMessage);

    // Update conversation lastMessageAt
    const conversation = this.conversations.get(message.conversationId);
    if (conversation) {
      conversation.lastMessageAt = new Date();
      this.conversations.set(message.conversationId, conversation);
    }

    return newMessage;
  }

  async deleteMessages(conversationId: string): Promise<boolean> {
    const messagesToDelete = Array.from(this.messages.keys())
      .filter(messageId => this.messages.get(messageId)?.conversationId === conversationId);
    
    let deleted = false;
    messagesToDelete.forEach(messageId => {
      if (this.messages.delete(messageId)) {
        deleted = true;
      }
    });
    
    return deleted;
  }

  // API Keys
  async getUserApiKeys(userId: string): Promise<ApiKey[]> {
    return Array.from(this.apiKeys.values()).filter(key => key.userId === userId);
  }

  async getUserApiKey(userId: string, provider: string): Promise<ApiKey | undefined> {
    return Array.from(this.apiKeys.values()).find(key => 
      key.userId === userId && key.provider === provider && key.isActive
    );
  }

  async createApiKey(apiKey: InsertApiKey & { userId: string }): Promise<ApiKey> {
    const id = randomUUID();
    
    // Deactivate existing keys for the same provider
    Array.from(this.apiKeys.values())
      .filter(key => key.userId === apiKey.userId && key.provider === apiKey.provider)
      .forEach(key => {
        key.isActive = false;
        this.apiKeys.set(key.id, key);
      });

    const newApiKey: ApiKey = {
      ...apiKey,
      id,
      isActive: true,
      createdAt: new Date(),
    };
    this.apiKeys.set(id, newApiKey);
    return newApiKey;
  }

  async updateApiKey(id: string, apiKey: Partial<ApiKey>): Promise<ApiKey | undefined> {
    const existing = this.apiKeys.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...apiKey };
    this.apiKeys.set(id, updated);
    return updated;
  }

  async deleteApiKey(id: string): Promise<boolean> {
    return this.apiKeys.delete(id);
  }

  async getGlobalApiKey(provider: string): Promise<ApiKey | undefined> {
    return Array.from(this.apiKeys.values()).find(key => 
      key.provider === provider && key.isGlobal && key.isActive
    );
  }

  // Voice Calls
  async getVoiceCall(conversationId: string): Promise<VoiceCall | undefined> {
    return Array.from(this.voiceCalls.values()).find(call => 
      call.conversationId === conversationId && call.status !== 'ended'
    );
  }

  async createVoiceCall(voiceCall: InsertVoiceCall & { userId: string }): Promise<VoiceCall> {
    const id = randomUUID();
    const newVoiceCall: VoiceCall = {
      ...voiceCall,
      id,
      startedAt: new Date(),
      endedAt: null,
      duration: null,
      createdAt: new Date(),
    };
    this.voiceCalls.set(id, newVoiceCall);
    return newVoiceCall;
  }

  async updateVoiceCall(id: string, voiceCall: Partial<VoiceCall>): Promise<VoiceCall | undefined> {
    const existing = this.voiceCalls.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...voiceCall };
    this.voiceCalls.set(id, updated);
    return updated;
  }

  async endVoiceCall(id: string): Promise<boolean> {
    const voiceCall = this.voiceCalls.get(id);
    if (!voiceCall) return false;

    const endedAt = new Date();
    const duration = voiceCall.startedAt 
      ? Math.floor((endedAt.getTime() - voiceCall.startedAt.getTime()) / 1000).toString()
      : "0";

    voiceCall.status = 'ended';
    voiceCall.endedAt = endedAt;
    voiceCall.duration = duration;
    
    this.voiceCalls.set(id, voiceCall);
    return true;
  }

  // Authentication
  async authenticateUser(username: string, password: string): Promise<User | null> {
    const user = Array.from(this.users.values()).find(u => 
      u.username === username && u.password === password
    );
    return user || null;
  }
}

export const storage = new MemStorage();
