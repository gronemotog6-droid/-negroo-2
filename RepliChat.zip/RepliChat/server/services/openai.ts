import OpenAI from "openai";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
export class OpenAIService {
  private client: OpenAI;

  constructor(apiKey: string) {
    this.client = new OpenAI({ apiKey });
  }

  async generateResponse(
    personality: string,
    messages: Array<{ role: 'user' | 'assistant'; content: string }>,
    model: string = 'gpt-5'
  ): Promise<string> {
    try {
      const systemMessage = {
        role: 'system' as const,
        content: `You are roleplaying as a character with this personality and background: ${personality}. Stay in character and respond as this character would. Keep responses conversational and engaging.`
      };

      const response = await this.client.chat.completions.create({
        model,
        messages: [systemMessage, ...messages],
        max_tokens: 1000,
        temperature: 0.8,
      });

      return response.choices[0]?.message?.content || "Lo siento, no pude generar una respuesta.";
    } catch (error) {
      console.error('OpenAI API Error:', error);
      throw new Error('Error al generar respuesta con OpenAI');
    }
  }

  async testConnection(): Promise<boolean> {
    try {
      const response = await this.client.chat.completions.create({
        model: 'gpt-5',
        messages: [{ role: 'user', content: 'Hello' }],
        max_tokens: 5,
      });
      return !!response.choices[0]?.message?.content;
    } catch (error) {
      return false;
    }
  }
}
