import { GoogleGenAI } from "@google/genai";

export class GeminiService {
  private ai: GoogleGenAI;

  constructor(apiKey: string) {
    this.ai = new GoogleGenAI({ apiKey });
  }

  async generateResponse(
    personality: string,
    messages: Array<{ role: 'user' | 'assistant'; content: string }>,
    model: string = 'gemini-2.5-flash'
  ): Promise<string> {
    try {
      // Convert messages to Gemini format
      const conversationHistory = messages.map(msg => ({
        role: msg.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: msg.content }]
      }));

      const lastUserMessage = messages[messages.length - 1]?.content || '';

      const systemPrompt = `You are roleplaying as a character with this personality and background: ${personality}. Stay in character and respond as this character would. Keep responses conversational and engaging.

Based on our conversation history, respond to the user's latest message: "${lastUserMessage}"`;

      const response = await this.ai.models.generateContent({
        model,
        contents: systemPrompt,
      });

      return response.text || "Lo siento, no pude generar una respuesta.";
    } catch (error) {
      console.error('Gemini API Error:', error);
      throw new Error('Error al generar respuesta con Gemini AI');
    }
  }

  async testConnection(): Promise<boolean> {
    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: 'Hello',
      });
      return !!response.text;
    } catch (error) {
      return false;
    }
  }
}
