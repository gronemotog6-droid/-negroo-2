import { useState, useEffect } from "react";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { X, CheckCircle, XCircle, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { getApiKeys, createApiKey, deleteApiKey } from "@/lib/api";
import ProtectedSettings from "./protected-settings";

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface ApiKeyState {
  provider: 'openai' | 'gemini' | 'elevenlabs';
  keyValue: string;
  isValid?: boolean;
  isLoading?: boolean;
}

export default function SettingsModal({ isOpen, onClose }: SettingsModalProps) {
  const [apiKeys, setApiKeys] = useState<Record<string, ApiKeyState>>({
    openai: { provider: 'openai', keyValue: '' },
    gemini: { provider: 'gemini', keyValue: '' },
    elevenlabs: { provider: 'elevenlabs', keyValue: '' },
  });
  const [autoVoice, setAutoVoice] = useState(true);
  const [darkMode, setDarkMode] = useState(true);
  const [language, setLanguage] = useState('es');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: savedApiKeys = [] } = useQuery({
    queryKey: ['/api/api-keys'],
    queryFn: () => getApiKeys(),
    enabled: isOpen,
  });

  const handleApiKeyChange = (provider: string, value: string) => {
    setApiKeys(prev => ({
      ...prev,
      [provider]: {
        ...prev[provider],
        keyValue: value,
        isValid: undefined,
      },
    }));
  };

  const handleSaveApiKey = async (provider: string) => {
    const keyData = apiKeys[provider];
    if (!keyData.keyValue.trim()) return;

    setApiKeys(prev => ({
      ...prev,
      [provider]: { ...prev[provider], isLoading: true },
    }));

    try {
      await createApiKey({
        provider: keyData.provider,
        keyValue: keyData.keyValue,
      });

      setApiKeys(prev => ({
        ...prev,
        [provider]: { ...prev[provider], isValid: true, isLoading: false },
      }));

      queryClient.invalidateQueries({ queryKey: ['/api/api-keys'] });

      toast({
        title: "API Key guardada",
        description: `Se configuró correctamente la API key de ${provider}`,
      });
    } catch (error) {
      setApiKeys(prev => ({
        ...prev,
        [provider]: { ...prev[provider], isValid: false, isLoading: false },
      }));

      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Error al guardar la API key",
        variant: "destructive",
      });
    }
  };

  const handleRemoveApiKey = async (provider: string) => {
    const savedKey = savedApiKeys.find(key => key.provider === provider);
    if (!savedKey) return;

    try {
      await deleteApiKey(savedKey.id);
      
      setApiKeys(prev => ({
        ...prev,
        [provider]: { provider: provider as any, keyValue: '', isValid: undefined },
      }));

      queryClient.invalidateQueries({ queryKey: ['/api/api-keys'] });

      toast({
        title: "API Key eliminada",
        description: `Se eliminó la API key de ${provider}`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Error al eliminar la API key",
        variant: "destructive",
      });
    }
  };

  const getStatusIcon = (provider: string) => {
    const keyData = apiKeys[provider];
    const savedKey = savedApiKeys.find(key => key.provider === provider);
    
    if (keyData.isLoading) {
      return <div className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse" />;
    }
    
    if (savedKey?.hasKey && keyData.isValid !== false) {
      return <CheckCircle className="w-4 h-4 text-green-400" />;
    }
    
    if (keyData.isValid === false) {
      return <XCircle className="w-4 h-4 text-red-400" />;
    }
    
    return <AlertCircle className="w-4 h-4 text-yellow-400" />;
  };

  const getStatusText = (provider: string) => {
    const keyData = apiKeys[provider];
    const savedKey = savedApiKeys.find(key => key.provider === provider);
    
    if (keyData.isLoading) return "Validando...";
    if (savedKey?.hasKey && keyData.isValid !== false) return "Conectado";
    if (keyData.isValid === false) return "Error";
    return "Sin configurar";
  };

  const handleSaveSettings = () => {
    // Save all pending API keys
    Object.keys(apiKeys).forEach(provider => {
      const keyData = apiKeys[provider];
      if (keyData.keyValue && keyData.isValid === undefined) {
        handleSaveApiKey(provider);
      }
    });

    toast({
      title: "Configuración guardada",
      description: "Se guardaron todos los cambios",
    });
    
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" data-testid="modal-settings">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            Configuración de APIs
            <Button variant="ghost" size="sm" onClick={onClose} data-testid="button-close-settings">
              <X className="h-4 w-4" />
            </Button>
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {!isAuthenticated ? (
            <ProtectedSettings
              onAuthenticated={() => setIsAuthenticated(true)}
              title="Configuración Protegida"
              description="Esta configuración requiere autenticación de administrador para proteger tus API keys privadas."
            />
          ) : (
            <>
              {/* OpenAI Section */}
              <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-green-600 rounded-lg flex items-center justify-center">
                  <span className="text-white text-sm font-bold">AI</span>
                </div>
                <div>
                  <h3 className="font-medium text-foreground">OpenAI</h3>
                  <p className="text-sm text-muted-foreground">GPT-3.5, GPT-4, y más</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-sm text-muted-foreground">{getStatusText('openai')}</span>
                {getStatusIcon('openai')}
              </div>
            </div>
            
            <div className="space-y-3">
              <div>
                <Label htmlFor="openai-key">API Key</Label>
                <div className="flex space-x-2">
                  <Input
                    id="openai-key"
                    type="password"
                    placeholder="sk-..."
                    value={apiKeys.openai.keyValue}
                    onChange={(e) => handleApiKeyChange('openai', e.target.value)}
                    data-testid="input-openai-key"
                  />
                  <Button
                    onClick={() => handleSaveApiKey('openai')}
                    disabled={!apiKeys.openai.keyValue.trim() || apiKeys.openai.isLoading}
                    data-testid="button-save-openai-key"
                  >
                    Guardar
                  </Button>
                  {savedApiKeys.find(key => key.provider === 'openai')?.hasKey && (
                    <Button
                      variant="destructive"
                      onClick={() => handleRemoveApiKey('openai')}
                      data-testid="button-remove-openai-key"
                    >
                      Eliminar
                    </Button>
                  )}
                </div>
              </div>
              
              <div>
                <Label>Modelo por defecto</Label>
                <Select defaultValue="gpt-5">
                  <SelectTrigger data-testid="select-openai-model">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="gpt-5">GPT-5</SelectItem>
                    <SelectItem value="gpt-4">GPT-4</SelectItem>
                    <SelectItem value="gpt-3.5-turbo">GPT-3.5 Turbo</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Gemini AI Section */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                  <span className="text-white text-sm font-bold">G</span>
                </div>
                <div>
                  <h3 className="font-medium text-foreground">Gemini AI</h3>
                  <p className="text-sm text-muted-foreground">Google's AI model</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-sm text-muted-foreground">{getStatusText('gemini')}</span>
                {getStatusIcon('gemini')}
              </div>
            </div>
            
            <div className="space-y-3">
              <div>
                <Label htmlFor="gemini-key">API Key</Label>
                <div className="flex space-x-2">
                  <Input
                    id="gemini-key"
                    type="password"
                    placeholder="AIza..."
                    value={apiKeys.gemini.keyValue}
                    onChange={(e) => handleApiKeyChange('gemini', e.target.value)}
                    data-testid="input-gemini-key"
                  />
                  <Button
                    onClick={() => handleSaveApiKey('gemini')}
                    disabled={!apiKeys.gemini.keyValue.trim() || apiKeys.gemini.isLoading}
                    data-testid="button-save-gemini-key"
                  >
                    Guardar
                  </Button>
                  {savedApiKeys.find(key => key.provider === 'gemini')?.hasKey && (
                    <Button
                      variant="destructive"
                      onClick={() => handleRemoveApiKey('gemini')}
                      data-testid="button-remove-gemini-key"
                    >
                      Eliminar
                    </Button>
                  )}
                </div>
              </div>
              
              <div>
                <Label>Modelo por defecto</Label>
                <Select defaultValue="gemini-2.5-flash">
                  <SelectTrigger data-testid="select-gemini-model">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="gemini-2.5-flash">Gemini 2.5 Flash</SelectItem>
                    <SelectItem value="gemini-2.5-pro">Gemini 2.5 Pro</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* ElevenLabs Section */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-purple-600 rounded-lg flex items-center justify-center">
                  <span className="text-white text-sm font-bold">11</span>
                </div>
                <div>
                  <h3 className="font-medium text-foreground">ElevenLabs</h3>
                  <p className="text-sm text-muted-foreground">Síntesis de voz realista</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-sm text-muted-foreground">{getStatusText('elevenlabs')}</span>
                {getStatusIcon('elevenlabs')}
              </div>
            </div>
            
            <div className="space-y-3">
              <div>
                <Label htmlFor="elevenlabs-key">API Key</Label>
                <div className="flex space-x-2">
                  <Input
                    id="elevenlabs-key"
                    type="password"
                    placeholder="your-api-key..."
                    value={apiKeys.elevenlabs.keyValue}
                    onChange={(e) => handleApiKeyChange('elevenlabs', e.target.value)}
                    data-testid="input-elevenlabs-key"
                  />
                  <Button
                    onClick={() => handleSaveApiKey('elevenlabs')}
                    disabled={!apiKeys.elevenlabs.keyValue.trim() || apiKeys.elevenlabs.isLoading}
                    data-testid="button-save-elevenlabs-key"
                  >
                    Guardar
                  </Button>
                  {savedApiKeys.find(key => key.provider === 'elevenlabs')?.hasKey && (
                    <Button
                      variant="destructive"
                      onClick={() => handleRemoveApiKey('elevenlabs')}
                      data-testid="button-remove-elevenlabs-key"
                    >
                      Eliminar
                    </Button>
                  )}
                </div>
              </div>
              
              <div>
                <Label>Voz por defecto</Label>
                <Select defaultValue="rachel">
                  <SelectTrigger data-testid="select-voice">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="rachel">Rachel - Femenina calmada</SelectItem>
                    <SelectItem value="drew">Drew - Masculina profunda</SelectItem>
                    <SelectItem value="clyde">Clyde - Masculina autoritaria</SelectItem>
                    <SelectItem value="paul">Paul - Masculina amigable</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* General Settings */}
          <div className="space-y-4">
            <h3 className="font-medium text-foreground">Configuración General</h3>
            
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="auto-voice">Activar síntesis de voz automática</Label>
                <p className="text-xs text-muted-foreground">Las respuestas se reproducirán automáticamente</p>
              </div>
              <Switch
                id="auto-voice"
                checked={autoVoice}
                onCheckedChange={setAutoVoice}
                data-testid="switch-auto-voice"
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="dark-mode">Modo oscuro</Label>
                <p className="text-xs text-muted-foreground">Usar tema oscuro en la interfaz</p>
              </div>
              <Switch
                id="dark-mode"
                checked={darkMode}
                onCheckedChange={setDarkMode}
                data-testid="switch-dark-mode"
              />
            </div>
            
            <div>
              <Label>Idioma de respuesta</Label>
              <Select value={language} onValueChange={setLanguage}>
                <SelectTrigger data-testid="select-language">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="es">Español</SelectItem>
                  <SelectItem value="en">English</SelectItem>
                  <SelectItem value="fr">Français</SelectItem>
                  <SelectItem value="de">Deutsch</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          </>
          )}
        </div>
        
        {isAuthenticated && (
          <div className="flex justify-end space-x-3 pt-6 border-t border-border">
            <Button variant="outline" onClick={onClose} data-testid="button-cancel-settings">
              Cancelar
            </Button>
            <Button onClick={handleSaveSettings} data-testid="button-save-settings">
              Guardar cambios
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
