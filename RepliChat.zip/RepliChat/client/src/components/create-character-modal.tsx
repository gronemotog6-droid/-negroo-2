import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { X, Camera } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { createCharacter } from "@/lib/api";

interface CreateCharacterModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCharacterCreated: (characterId: string) => void;
}

export default function CreateCharacterModal({
  isOpen,
  onClose,
  onCharacterCreated,
}: CreateCharacterModalProps) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [personality, setPersonality] = useState("");
  const [aiProvider, setAiProvider] = useState<'openai' | 'gemini'>('openai');
  const [model, setModel] = useState("gpt-5");
  const [voiceId, setVoiceId] = useState("rachel");
  const [avatarUrl, setAvatarUrl] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const queryClient = useQueryClient();
  const { toast } = useToast();

  const handleProviderChange = (provider: 'openai' | 'gemini') => {
    setAiProvider(provider);
    // Set default model for provider
    if (provider === 'openai') {
      setModel('gpt-5');
    } else {
      setModel('gemini-2.5-flash');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name.trim() || !description.trim() || !personality.trim()) {
      toast({
        title: "Campos requeridos",
        description: "Por favor completa todos los campos obligatorios",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);

    try {
      const character = await createCharacter({
        name: name.trim(),
        description: description.trim(),
        personality: personality.trim(),
        aiProvider,
        model,
        voiceId: voiceId || undefined,
        avatarUrl: avatarUrl || undefined,
        isPublic: false,
        userId: 'anonymous', // In a real app, get from session
      });

      // Invalidate characters query to refetch
      queryClient.invalidateQueries({ queryKey: ['/api/characters'] });

      toast({
        title: "Personaje creado",
        description: `${character.name} ha sido creado exitosamente`,
      });

      onCharacterCreated(character.id);
      handleClose();
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Error al crear el personaje",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleClose = () => {
    setName("");
    setDescription("");
    setPersonality("");
    setAiProvider('openai');
    setModel('gpt-5');
    setVoiceId('rachel');
    setAvatarUrl("");
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto" data-testid="modal-create-character">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            Crear Nuevo Personaje
            <Button variant="ghost" size="sm" onClick={handleClose} data-testid="button-close-create-character">
              <X className="h-4 w-4" />
            </Button>
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Character Avatar */}
          <div className="flex flex-col items-center space-y-3">
            <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center border-2 border-dashed border-border cursor-pointer hover:bg-muted/80 transition-colors">
              {avatarUrl ? (
                <img src={avatarUrl} alt="Avatar preview" className="w-full h-full rounded-full object-cover" />
              ) : (
                <Camera className="h-8 w-8 text-muted-foreground" />
              )}
            </div>
            <div>
              <Label htmlFor="avatar-url">URL de imagen (opcional)</Label>
              <Input
                id="avatar-url"
                type="url"
                placeholder="https://ejemplo.com/imagen.jpg"
                value={avatarUrl}
                onChange={(e) => setAvatarUrl(e.target.value)}
                data-testid="input-avatar-url"
              />
            </div>
          </div>
          
          {/* Character Info */}
          <div className="space-y-4">
            <div>
              <Label htmlFor="character-name">Nombre del personaje *</Label>
              <Input
                id="character-name"
                type="text"
                placeholder="ej. Leonardo da Vinci"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                data-testid="input-character-name"
              />
            </div>
            
            <div>
              <Label htmlFor="character-description">Descripción corta *</Label>
              <Input
                id="character-description"
                type="text"
                placeholder="ej. Artista renacentista y genio universal"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                required
                data-testid="input-character-description"
              />
            </div>
            
            <div>
              <Label htmlFor="character-personality">Personalidad y contexto *</Label>
              <Textarea
                id="character-personality"
                placeholder="Describe la personalidad, trasfondo histórico, conocimientos, y cómo debe comportarse este personaje..."
                value={personality}
                onChange={(e) => setPersonality(e.target.value)}
                className="h-24 resize-none"
                required
                data-testid="textarea-character-personality"
              />
            </div>
            
            <div>
              <Label>Modelo de IA *</Label>
              <Select value={aiProvider} onValueChange={handleProviderChange}>
                <SelectTrigger data-testid="select-ai-provider">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="openai">OpenAI</SelectItem>
                  <SelectItem value="gemini">Gemini AI</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {aiProvider && (
              <div>
                <Label>Modelo específico</Label>
                <Select value={model} onValueChange={setModel}>
                  <SelectTrigger data-testid="select-model">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {aiProvider === 'openai' ? (
                      <>
                        <SelectItem value="gpt-5">GPT-5</SelectItem>
                        <SelectItem value="gpt-4">GPT-4</SelectItem>
                        <SelectItem value="gpt-3.5-turbo">GPT-3.5 Turbo</SelectItem>
                      </>
                    ) : (
                      <>
                        <SelectItem value="gemini-2.5-flash">Gemini 2.5 Flash</SelectItem>
                        <SelectItem value="gemini-2.5-pro">Gemini 2.5 Pro</SelectItem>
                      </>
                    )}
                  </SelectContent>
                </Select>
              </div>
            )}
            
            <div>
              <Label>Voz (ElevenLabs)</Label>
              <Select value={voiceId} onValueChange={setVoiceId}>
                <SelectTrigger data-testid="select-voice-id">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Sin voz</SelectItem>
                  <SelectItem value="rachel">Rachel - Femenina calmada</SelectItem>
                  <SelectItem value="drew">Drew - Masculina profunda</SelectItem>
                  <SelectItem value="clyde">Clyde - Masculina autoritaria</SelectItem>
                  <SelectItem value="paul">Paul - Masculina amigable</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="flex justify-end space-x-3 pt-6 border-t border-border">
            <Button type="button" variant="outline" onClick={handleClose} data-testid="button-cancel-create-character">
              Cancelar
            </Button>
            <Button type="submit" disabled={isLoading} data-testid="button-save-character">
              {isLoading ? "Creando..." : "Crear personaje"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
