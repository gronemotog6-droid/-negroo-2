import { Play, User } from "lucide-react";
import { Button } from "@/components/ui/button";

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  audioUrl?: string;
  createdAt: Date;
}

interface Character {
  id: string;
  name: string;
  avatarUrl?: string;
}

interface MessageBubbleProps {
  message: Message;
  character: Character;
  isVoiceEnabled: boolean;
}

export default function MessageBubble({ message, character, isVoiceEnabled }: MessageBubbleProps) {
  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const messageDate = new Date(date);
    const diff = now.getTime() - messageDate.getTime();
    const minutes = Math.floor(diff / (1000 * 60));
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));

    if (minutes < 1) return 'ahora';
    if (minutes < 60) return `hace ${minutes}m`;
    if (hours < 24) return `hace ${hours}h`;
    return `hace ${days}d`;
  };

  const playAudio = () => {
    if (message.audioUrl) {
      try {
        const audio = new Audio(message.audioUrl);
        audio.play().catch(console.error);
      } catch (error) {
        console.error('Error playing audio:', error);
      }
    }
  };

  if (message.role === 'user') {
    return (
      <div className="flex items-start space-x-3 justify-end" data-testid={`message-user-${message.id}`}>
        <div className="message-bubble bg-primary p-3 rounded-lg rounded-tr-sm">
          <p className="text-primary-foreground text-sm">{message.content}</p>
          <div className="flex items-center gap-2 mt-2 justify-end">
            <span className="text-xs text-primary-foreground/70">
              {formatTimeAgo(message.createdAt)}
            </span>
          </div>
        </div>
        <div className="w-8 h-8 rounded-full bg-accent flex items-center justify-center flex-shrink-0 mt-1">
          <User className="h-4 w-4 text-accent-foreground" />
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-start space-x-3" data-testid={`message-assistant-${message.id}`}>
      <img 
        src={character.avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${character.name}`}
        alt={character.name}
        className="w-8 h-8 rounded-full object-cover flex-shrink-0 mt-1"
      />
      <div className="message-bubble bg-secondary p-3 rounded-lg rounded-tl-sm">
        <p className="text-foreground text-sm">{message.content}</p>
        <div className="flex items-center gap-2 mt-2">
          <span className="text-xs text-muted-foreground">
            {formatTimeAgo(message.createdAt)}
          </span>
          {message.audioUrl && isVoiceEnabled && (
            <Button
              variant="ghost"
              size="sm"
              onClick={playAudio}
              className="text-xs text-muted-foreground hover:text-accent transition-colors p-0 h-auto"
              data-testid={`button-play-audio-${message.id}`}
            >
              <Play className="h-3 w-3 mr-1" />
              Reproducir
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
