import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Phone, PhoneOff, Mic, MicOff, Volume2 } from "lucide-react";
import { useWebSocket } from "@/hooks/use-websocket";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

interface VoiceCallControlsProps {
  conversationId: string;
  userId: string;
  characterName: string;
}

interface VoiceCallState {
  status: 'idle' | 'connecting' | 'active' | 'ended';
  duration: number;
  isMuted: boolean;
  voiceCallId?: string;
}

export default function VoiceCallControls({ 
  conversationId, 
  userId, 
  characterName 
}: VoiceCallControlsProps) {
  const [callState, setCallState] = useState<VoiceCallState>({
    status: 'idle',
    duration: 0,
    isMuted: false,
  });
  
  const [isListening, setIsListening] = useState(false);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const { toast } = useToast();

  const { sendMessage, lastMessage } = useWebSocket('/ws');

  // Join conversation when component mounts
  useEffect(() => {
    if (sendMessage) {
      sendMessage({
        type: 'join-conversation',
        conversationId,
        userId,
      });
    }
  }, [sendMessage, conversationId, userId]);

  // Handle WebSocket messages
  useEffect(() => {
    if (lastMessage) {
      try {
        const message = JSON.parse(lastMessage.data);
        
        if (message.type === 'voice-call-started') {
          setCallState(prev => ({
            ...prev,
            status: 'active',
            voiceCallId: message.voiceCallId,
          }));
          startTimer();
          toast({
            title: "Llamada iniciada",
            description: `Conectado con ${characterName}`,
          });
        }
        
        if (message.type === 'voice-call-ended') {
          setCallState(prev => ({
            ...prev,
            status: 'ended',
          }));
          stopTimer();
          stopListening();
          toast({
            title: "Llamada finalizada",
            description: `Duración: ${formatDuration(callState.duration)}`,
          });
        }
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    }
  }, [lastMessage, characterName, callState.duration, toast]);

  const startTimer = () => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    
    intervalRef.current = setInterval(() => {
      setCallState(prev => ({
        ...prev,
        duration: prev.duration + 1,
      }));
    }, 1000);
  };

  const stopTimer = () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  };

  const startVoiceCall = async () => {
    try {
      setCallState(prev => ({ ...prev, status: 'connecting' }));
      
      // Request microphone access
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      // Initialize MediaRecorder for voice capture
      mediaRecorderRef.current = new MediaRecorder(stream);
      
      sendMessage({
        type: 'start-voice-call',
        conversationId,
        userId,
      });
    } catch (error) {
      console.error('Error starting voice call:', error);
      toast({
        title: "Error",
        description: "No se pudo acceder al micrófono",
        variant: "destructive",
      });
      setCallState(prev => ({ ...prev, status: 'idle' }));
    }
  };

  const endVoiceCall = () => {
    sendMessage({
      type: 'end-voice-call',
      conversationId,
      userId,
    });
    
    // Stop recording
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
    
    setCallState({
      status: 'idle',
      duration: 0,
      isMuted: false,
    });
    stopTimer();
    stopListening();
  };

  const toggleMute = () => {
    setCallState(prev => ({ ...prev, isMuted: !prev.isMuted }));
    
    if (mediaRecorderRef.current) {
      const tracks = (mediaRecorderRef.current.stream as MediaStream).getTracks();
      tracks.forEach(track => {
        track.enabled = callState.isMuted;
      });
    }
  };

  const startListening = async () => {
    if (!mediaRecorderRef.current) return;
    
    try {
      setIsListening(true);
      mediaRecorderRef.current.start();
      
      mediaRecorderRef.current.ondataavailable = (event) => {
        if (event.data.size > 0) {
          // Here you would send the audio data to the server
          // for processing and AI response generation
          console.log('Audio data received:', event.data);
        }
      };
      
      // Auto-stop after 10 seconds
      setTimeout(() => {
        if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
          mediaRecorderRef.current.stop();
          setIsListening(false);
        }
      }, 10000);
    } catch (error) {
      console.error('Error starting voice recording:', error);
      setIsListening(false);
    }
  };

  const stopListening = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.stop();
    }
    setIsListening(false);
  };

  const formatDuration = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <Card className="w-full" data-testid="voice-call-controls">
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Volume2 className="w-4 h-4" />
            <span className="font-medium">Llamada con {characterName}</span>
          </div>
          
          <Badge 
            variant={callState.status === 'active' ? 'default' : 'secondary'}
            data-testid={`status-${callState.status}`}
          >
            {callState.status === 'idle' && 'Desconectado'}
            {callState.status === 'connecting' && 'Conectando...'}
            {callState.status === 'active' && `Activa - ${formatDuration(callState.duration)}`}
            {callState.status === 'ended' && 'Finalizada'}
          </Badge>
        </div>

        <div className="flex items-center justify-center gap-4">
          {callState.status === 'idle' && (
            <Button
              onClick={startVoiceCall}
              size="lg"
              className="bg-green-600 hover:bg-green-700"
              data-testid="button-start-call"
            >
              <Phone className="w-5 h-5 mr-2" />
              Iniciar Llamada
            </Button>
          )}

          {(callState.status === 'connecting' || callState.status === 'active') && (
            <>
              <Button
                onClick={toggleMute}
                variant="outline"
                size="lg"
                className={cn(
                  "border-2",
                  callState.isMuted ? "border-red-500 text-red-500" : "border-gray-300"
                )}
                data-testid="button-toggle-mute"
              >
                {callState.isMuted ? (
                  <MicOff className="w-5 h-5" />
                ) : (
                  <Mic className="w-5 h-5" />
                )}
              </Button>

              {callState.status === 'active' && (
                <Button
                  onClick={isListening ? stopListening : startListening}
                  variant={isListening ? "default" : "outline"}
                  size="lg"
                  className={cn(
                    isListening && "bg-blue-600 hover:bg-blue-700 animate-pulse"
                  )}
                  data-testid="button-voice-input"
                >
                  <Mic className="w-5 h-5 mr-2" />
                  {isListening ? "Escuchando..." : "Hablar"}
                </Button>
              )}

              <Button
                onClick={endVoiceCall}
                size="lg"
                className="bg-red-600 hover:bg-red-700"
                data-testid="button-end-call"
              >
                <PhoneOff className="w-5 h-5 mr-2" />
                Finalizar
              </Button>
            </>
          )}
        </div>

        {callState.status === 'active' && (
          <div className="mt-4 text-center">
            <p className="text-sm text-muted-foreground">
              Haz clic en "Hablar" para enviar un mensaje de voz al personaje
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}