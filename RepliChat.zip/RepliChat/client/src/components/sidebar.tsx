import { useQuery } from "@tanstack/react-query";
import { Search, Plus, Settings, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { getCharacters, getConversations } from "@/lib/api";
import { useState } from "react";

interface SidebarProps {
  selectedCharacterId: string;
  onCharacterSelect: (characterId: string, conversationId?: string) => void;
  onOpenSettings: () => void;
  onOpenCreateCharacter: () => void;
  onCloseSidebar: () => void;
  isMobile: boolean;
}

export default function Sidebar({
  selectedCharacterId,
  onCharacterSelect,
  onOpenSettings,
  onOpenCreateCharacter,
  onCloseSidebar,
  isMobile,
}: SidebarProps) {
  const [searchQuery, setSearchQuery] = useState("");

  const { data: characters = [] } = useQuery({
    queryKey: ['/api/characters'],
    queryFn: () => getCharacters(),
  });

  const { data: conversations = [] } = useQuery({
    queryKey: ['/api/conversations'],
    queryFn: () => getConversations(),
  });

  const filteredCharacters = characters.filter(character =>
    character.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    character.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const recentConversations = conversations.slice(0, 5);
  const popularCharacters = filteredCharacters.filter(char => 
    !recentConversations.find(conv => conv.characterId === char.id)
  ).slice(0, 10);

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - new Date(date).getTime();
    const minutes = Math.floor(diff / (1000 * 60));
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));

    if (minutes < 60) return `hace ${minutes}m`;
    if (hours < 24) return `hace ${hours}h`;
    return `hace ${days}d`;
  };

  const getProviderColor = (provider: string) => {
    switch (provider) {
      case 'openai': return 'text-green-400';
      case 'gemini': return 'text-blue-400';
      default: return 'text-gray-400';
    }
  };

  const getProviderName = (provider: string) => {
    switch (provider) {
      case 'openai': return 'OpenAI';
      case 'gemini': return 'Gemini AI';
      default: return provider;
    }
  };

  return (
    <>
      {/* Sidebar Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-xl font-bold text-primary" data-testid="app-title">Character AI</h1>
          {isMobile && (
            <Button
              variant="ghost"
              size="sm"
              onClick={onCloseSidebar}
              data-testid="button-close-sidebar"
            >
              <X className="h-4 w-4" />
            </Button>
          )}
        </div>
        
        {/* Search Bar */}
        <div className="relative">
          <Input
            type="text"
            placeholder="Buscar personajes..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
            data-testid="input-search-characters"
          />
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
        </div>
        
        {/* Action Buttons */}
        <div className="flex gap-2 mt-3">
          <Button
            onClick={onOpenCreateCharacter}
            className="flex-1"
            data-testid="button-create-character"
          >
            <Plus className="h-4 w-4 mr-2" />
            Crear
          </Button>
          <Button
            variant="secondary"
            size="sm"
            onClick={onOpenSettings}
            data-testid="button-settings"
          >
            <Settings className="h-4 w-4" />
          </Button>
        </div>
      </div>
      
      {/* Character List */}
      <div className="flex-1 overflow-y-auto scrollbar-thin">
        <div className="p-4 space-y-3">
          {/* Recent Chats Section */}
          {recentConversations.length > 0 && (
            <div className="mb-4">
              <h3 className="text-sm font-medium text-muted-foreground mb-2">Chats Recientes</h3>
              
              {recentConversations.map((conversation) => (
                <div
                  key={conversation.id}
                  className={`
                    character-item p-3 rounded-lg cursor-pointer transition-colors mb-2 border border-border/50
                    ${conversation.characterId === selectedCharacterId 
                      ? 'bg-secondary border-primary/50' 
                      : 'bg-secondary/50 hover:bg-secondary/80'
                    }
                  `}
                  onClick={() => onCharacterSelect(conversation.characterId, conversation.id)}
                  data-testid={`conversation-item-${conversation.id}`}
                >
                  <div className="flex items-center space-x-3">
                    <img 
                      src={conversation.character?.avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${conversation.character?.name}`}
                      alt={`${conversation.character?.name} avatar`}
                      className="w-10 h-10 rounded-full object-cover"
                    />
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-foreground text-sm">{conversation.character?.name}</h4>
                      <p className="text-xs text-muted-foreground truncate">
                        {conversation.lastMessage?.content || "Nueva conversación"}
                      </p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className={`text-xs ${getProviderColor(conversation.character?.aiProvider || '')}`}>
                          {getProviderName(conversation.character?.aiProvider || '')}
                        </span>
                        <span className="text-xs text-muted-foreground">•</span>
                        <span className="text-xs text-muted-foreground">
                          {formatTimeAgo(conversation.lastMessageAt)}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
          
          {/* Popular Characters Section */}
          <div>
            <h3 className="text-sm font-medium text-muted-foreground mb-2">
              {searchQuery ? 'Resultados' : 'Personajes Populares'}
            </h3>
            
            {filteredCharacters.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-muted-foreground text-sm">
                  {searchQuery ? 'No se encontraron personajes' : 'No hay personajes disponibles'}
                </p>
              </div>
            ) : (
              popularCharacters.map((character) => (
                <div
                  key={character.id}
                  className={`
                    character-item p-3 rounded-lg cursor-pointer transition-colors mb-2
                    ${character.id === selectedCharacterId && !recentConversations.find(c => c.characterId === character.id)
                      ? 'bg-secondary border border-primary/50' 
                      : 'hover:bg-secondary/50'
                    }
                  `}
                  onClick={() => onCharacterSelect(character.id)}
                  data-testid={`character-item-${character.id}`}
                >
                  <div className="flex items-center space-x-3">
                    <img 
                      src={character.avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${character.name}`}
                      alt={`${character.name} avatar`}
                      className="w-10 h-10 rounded-full object-cover"
                    />
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-foreground text-sm">{character.name}</h4>
                      <p className="text-xs text-muted-foreground">{character.description}</p>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </>
  );
}
