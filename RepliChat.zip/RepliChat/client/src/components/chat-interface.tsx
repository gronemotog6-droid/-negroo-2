import { useEffect, useState, useRef } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Menu, Volume2, VolumeX, Trash2, MoreVertical, Send, Paperclip, Mic, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useWebSocket } from "@/hooks/use-websocket";
import { useToast } from "@/hooks/use-toast";
import { getCharacter, getMessages, createConversation, clearConversation } from "@/lib/api";
import MessageBubble from "./message-bubble";
import VoiceCallControls from "./voice-call-controls";

interface ChatInterfaceProps {
  characterId: string;
  conversationId: string | null;
  onNewConversation: (conversationId: string) => void;
  onToggleSidebar: () => void;
  isMobile: boolean;
}

export default function ChatInterface({
  characterId,
  conversationId,
  onNewConversation,
  onToggleSidebar,
  isMobile,
}: ChatInterfaceProps) {
  const [message, setMessage] = useState("");
  const [isVoiceEnabled, setIsVoiceEnabled] = useState(true);
  const [isTyping, setIsTyping] = useState(false);
  const [showVoiceCall, setShowVoiceCall] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { lastMessage, sendChatMessage, joinConversation, isConnected } = useWebSocket('/ws');

  const { data: character } = useQuery({
    queryKey: ['/api/characters', characterId],
    queryFn: () => getCharacter(characterId),
    enabled: !!characterId,
  });

  const { data: messages = [] } = useQuery({
    queryKey: ['/api/conversations', conversationId, 'messages'],
    queryFn: () => conversationId ? getMessages(conversationId) : [],
    enabled: !!conversationId,
  });

  // Handle WebSocket messages
  useEffect(() => {
    if (!lastMessage) return;

    if (lastMessage.type === 'new-message') {
      // Invalidate messages query to refetch
      queryClient.invalidateQueries({
        queryKey: ['/api/conversations', conversationId, 'messages']
      });
      
      if (lastMessage.message.role === 'assistant') {
        setIsTyping(false);
        
        // Play audio if available and voice is enabled
        if (isVoiceEnabled && lastMessage.message.audioUrl) {
          try {
            const audio = new Audio(lastMessage.message.audioUrl);
            audio.play().catch(console.error);
          } catch (error) {
            console.error('Error playing audio:', error);
          }
        }
      }
    } else if (lastMessage.type === 'error') {
      setIsTyping(false);
      toast({
        title: "Error",
        description: lastMessage.message,
        variant: "destructive",
      });
    }
  }, [lastMessage, queryClient, conversationId, isVoiceEnabled, toast]);

  // Join conversation when it changes
  useEffect(() => {
    if (conversationId && isConnected) {
      joinConversation(conversationId);
    }
  }, [conversationId, isConnected, joinConversation]);

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  // Auto-resize textarea
  const handleMessageChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setMessage(e.target.value);
    e.target.style.height = 'auto';
    e.target.style.height = Math.min(e.target.scrollHeight, 128) + 'px';
  };

  const handleSendMessage = async () => {
    if (!message.trim()) return;

    let activeConversationId = conversationId;

    // Create new conversation if none exists
    if (!activeConversationId && character) {
      try {
        const newConversation = await createConversation({
          characterId: character.id,
          title: `Chat con ${character.name}`,
        });
        activeConversationId = newConversation.id;
        onNewConversation(activeConversationId);
        
        // Join the new conversation
        joinConversation(activeConversationId);
      } catch (error) {
        toast({
          title: "Error",
          description: "No se pudo crear la conversación",
          variant: "destructive",
        });
        return;
      }
    }

    if (!activeConversationId) {
      toast({
        title: "Error",
        description: "No hay conversación activa",
        variant: "destructive",
      });
      return;
    }

    // Send message via WebSocket
    sendChatMessage(message);
    setMessage("");
    setIsTyping(true);

    // Reset textarea height
    const textarea = document.getElementById('messageInput') as HTMLTextAreaElement;
    if (textarea) {
      textarea.style.height = 'auto';
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleClearChat = async () => {
    if (!conversationId) return;
    
    if (window.confirm('¿Estás seguro de que quieres borrar toda la conversación?')) {
      try {
        await clearConversation(conversationId);
        queryClient.invalidateQueries({
          queryKey: ['/api/conversations', conversationId, 'messages']
        });
        toast({
          title: "Conversación limpiada",
          description: "Se han eliminado todos los mensajes",
        });
      } catch (error) {
        toast({
          title: "Error",
          description: "No se pudo limpiar la conversación",
          variant: "destructive",
        });
      }
    }
  };

  const getProviderColor = (provider: string) => {
    switch (provider) {
      case 'openai': return 'text-green-400';
      case 'gemini': return 'text-blue-400';
      default: return 'text-gray-400';
    }
  };

  const getProviderName = (provider: string, model: string) => {
    switch (provider) {
      case 'openai': return `OpenAI ${model.toUpperCase()}`;
      case 'gemini': return `Gemini ${model.split('-')[1]?.toUpperCase() || 'AI'}`;
      default: return provider;
    }
  };

  if (!character) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-center">
          <h3 className="text-lg font-semibold text-muted-foreground">Cargando personaje...</h3>
        </div>
      </div>
    );
  }

  return (
    <>
      {/* Chat Header */}
      <div className="bg-card border-b border-border p-4 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          {isMobile && (
            <Button
              variant="ghost"
              size="sm"
              onClick={onToggleSidebar}
              data-testid="button-toggle-sidebar"
            >
              <Menu className="h-4 w-4" />
            </Button>
          )}
          <img 
            src={character.avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${character.name}`}
            alt={`${character.name} avatar`}
            className="w-10 h-10 rounded-full object-cover"
            data-testid="img-character-avatar"
          />
          <div>
            <h2 className="font-semibold text-foreground" data-testid="text-character-name">
              {character.name}
            </h2>
            <div className="flex items-center gap-2">
              <span className={`text-sm ${getProviderColor(character.aiProvider)}`}>
                {getProviderName(character.aiProvider, character.model)}
              </span>
              <span className="text-sm text-muted-foreground">•</span>
              <span className={`text-sm ${isConnected ? 'text-green-400' : 'text-red-400'}`}>
                {isConnected ? 'En línea' : 'Desconectado'}
              </span>
            </div>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsVoiceEnabled(!isVoiceEnabled)}
            className={isVoiceEnabled ? 'text-accent' : 'text-muted-foreground'}
            data-testid="button-toggle-voice"
          >
            {isVoiceEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
          </Button>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowVoiceCall(!showVoiceCall)}
            data-testid="button-toggle-voice-call"
            className="text-muted-foreground hover:text-foreground"
          >
            <Phone className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleClearChat}
            disabled={!conversationId || messages.length === 0}
            data-testid="button-clear-chat"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" data-testid="button-more-options">
            <MoreVertical className="h-4 w-4" />
          </Button>
        </div>
      </div>
      
      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto scrollbar-thin p-4 space-y-4" data-testid="chat-container">
        {messages.length === 0 ? (
          /* Welcome Message */
          <div className="text-center py-8">
            <div className="max-w-md mx-auto">
              <img 
                src={character.avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${character.name}`}
                alt={`${character.name} portrait`}
                className="w-20 h-20 rounded-full mx-auto mb-4 object-cover"
                data-testid="img-character-welcome"
              />
              <h3 className="text-lg font-semibold text-foreground mb-2">
                ¡Hola! Soy {character.name}
              </h3>
              <p className="text-muted-foreground text-sm">
                {character.description}. ¿En qué puedo ayudarte hoy?
              </p>
            </div>
          </div>
        ) : (
          /* Message List */
          messages.map((msg) => (
            <MessageBubble
              key={msg.id}
              message={msg}
              character={character}
              isVoiceEnabled={isVoiceEnabled}
            />
          ))
        )}
        
        {/* Typing Indicator */}
        {isTyping && (
          <div className="flex items-start space-x-3" data-testid="typing-indicator">
            <img 
              src={character.avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${character.name}`}
              alt={character.name}
              className="w-8 h-8 rounded-full object-cover flex-shrink-0 mt-1"
            />
            <div className="bg-secondary p-3 rounded-lg rounded-tl-sm">
              <div className="flex space-x-1">
                <div className="dot animate-typing" style={{ animationDelay: '-0.32s' }}></div>
                <div className="dot animate-typing" style={{ animationDelay: '-0.16s' }}></div>
                <div className="dot animate-typing"></div>
              </div>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>

      {/* Voice Call Controls */}
      {showVoiceCall && conversationId && (
        <div className="border-t border-border p-4 bg-card">
          <VoiceCallControls
            conversationId={conversationId}
            userId="anonymous" // Replace with actual user ID when auth is implemented
            characterName={character.name}
          />
        </div>
      )}
      
      {/* Message Input */}
      <div className="bg-card border-t border-border p-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-end space-x-3">
            <div className="flex-1 relative">
              <Textarea
                id="messageInput"
                placeholder="Escribe tu mensaje aquí..."
                value={message}
                onChange={handleMessageChange}
                onKeyPress={handleKeyPress}
                className="resize-none pr-20 max-h-32"
                rows={1}
                data-testid="input-message"
              />
              <div className="absolute right-2 bottom-2 flex items-center space-x-1">
                <Button variant="ghost" size="sm" data-testid="button-attach">
                  <Paperclip className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="sm" data-testid="button-microphone">
                  <Mic className="h-4 w-4" />
                </Button>
              </div>
            </div>
            <Button
              onClick={handleSendMessage}
              disabled={!message.trim() || isTyping}
              data-testid="button-send"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </>
  );
}
