import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, Lock, Key } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ProtectedSettingsProps {
  onAuthenticated: () => void;
  title: string;
  description: string;
}

export default function ProtectedSettings({ 
  onAuthenticated, 
  title, 
  description 
}: ProtectedSettingsProps) {
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleAuthenticate = async () => {
    if (!password.trim()) {
      toast({
        title: "Error",
        description: "Por favor ingresa tu contraseña",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    
    try {
      // Verify admin credentials
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: "admin",
          password: password,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        if (data.user.isAdmin) {
          toast({
            title: "Acceso autorizado",
            description: "Configuración de API keys desbloqueada",
          });
          onAuthenticated();
        } else {
          toast({
            title: "Acceso denegado",
            description: "Se requieren privilegios de administrador",
            variant: "destructive",
          });
        }
      } else {
        toast({
          title: "Credenciales incorrectas",
          description: "La contraseña ingresada no es válida",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error de conexión",
        description: "No se pudo verificar las credenciales",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
      setPassword("");
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleAuthenticate();
    }
  };

  return (
    <div className="flex items-center justify-center min-h-[400px]">
      <Card className="w-full max-w-md" data-testid="protected-settings">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4 p-3 bg-amber-100 dark:bg-amber-900/20 rounded-full w-fit">
            <Shield className="w-8 h-8 text-amber-600 dark:text-amber-400" />
          </div>
          <CardTitle className="text-xl font-bold">{title}</CardTitle>
          <CardDescription className="text-sm">
            {description}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="admin-password" className="flex items-center gap-2">
              <Lock className="w-4 h-4" />
              Contraseña de Administrador
            </Label>
            <Input
              id="admin-password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Ingresa la contraseña de administrador"
              className="w-full"
              data-testid="input-admin-password"
            />
          </div>

          <Button
            onClick={handleAuthenticate}
            disabled={isLoading || !password.trim()}
            className="w-full"
            data-testid="button-authenticate"
          >
            {isLoading ? (
              "Verificando..."
            ) : (
              <>
                <Key className="w-4 h-4 mr-2" />
                Desbloquear Configuración
              </>
            )}
          </Button>

          <div className="mt-6 p-4 bg-muted rounded-lg">
            <p className="text-sm text-muted-foreground mb-2">
              🔒 <strong>Configuración Protegida:</strong>
            </p>
            <ul className="text-xs text-muted-foreground space-y-1">
              <li>• Solo administradores pueden modificar API keys</li>
              <li>• Las claves se almacenan de forma segura</li>
              <li>• Solo tú tienes acceso a esta configuración</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}