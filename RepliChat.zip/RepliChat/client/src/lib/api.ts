import { apiRequest } from "./queryClient";

export interface Character {
  id: string;
  name: string;
  description: string;
  personality: string;
  aiProvider: string;
  model: string;
  voiceId?: string;
  avatarUrl?: string;
  isPublic: boolean;
  createdBy?: string | null;
  createdAt: Date;
}

export interface Conversation {
  id: string;
  userId: string;
  characterId: string;
  title?: string;
  lastMessageAt: Date;
  createdAt: Date;
  character?: Character;
  lastMessage?: Message;
  messageCount?: number;
}

export interface Message {
  id: string;
  conversationId: string;
  role: 'user' | 'assistant';
  content: string;
  audioUrl?: string;
  createdAt: Date;
}

export interface ApiKey {
  id: string;
  userId: string;
  provider: 'openai' | 'gemini' | 'elevenlabs';
  keyValue: string;
  isActive: boolean;
  createdAt: Date;
  hasKey?: boolean;
}

// Characters
export const getCharacters = async (): Promise<Character[]> => {
  const response = await fetch('/api/characters');
  if (!response.ok) throw new Error('Failed to fetch characters');
  return response.json();
};

export const getCharacter = async (id: string): Promise<Character> => {
  const response = await fetch(`/api/characters/${id}`);
  if (!response.ok) throw new Error('Failed to fetch character');
  return response.json();
};

export const createCharacter = async (character: Omit<Character, 'id' | 'createdAt'> & { userId: string }): Promise<Character> => {
  const response = await apiRequest('POST', '/api/characters', character);
  return response.json();
};

// Conversations
export const getConversations = async (userId: string = 'anonymous'): Promise<Conversation[]> => {
  const response = await fetch(`/api/conversations?userId=${userId}`);
  if (!response.ok) throw new Error('Failed to fetch conversations');
  return response.json();
};

export const createConversation = async (conversation: { characterId: string; title?: string; userId?: string }): Promise<Conversation> => {
  const response = await apiRequest('POST', '/api/conversations', {
    ...conversation,
    userId: conversation.userId || 'anonymous',
  });
  return response.json();
};

export const clearConversation = async (conversationId: string): Promise<void> => {
  await apiRequest('DELETE', `/api/conversations/${conversationId}/messages`);
};

// Messages
export const getMessages = async (conversationId: string): Promise<Message[]> => {
  const response = await fetch(`/api/conversations/${conversationId}/messages`);
  if (!response.ok) throw new Error('Failed to fetch messages');
  return response.json();
};

// API Keys
export const getApiKeys = async (userId: string = 'anonymous'): Promise<ApiKey[]> => {
  const response = await fetch(`/api/api-keys?userId=${userId}`);
  if (!response.ok) throw new Error('Failed to fetch API keys');
  return response.json();
};

export const createApiKey = async (apiKey: { provider: string; keyValue: string; userId?: string }): Promise<ApiKey> => {
  const response = await apiRequest('POST', '/api/api-keys', {
    ...apiKey,
    userId: apiKey.userId || 'anonymous',
  });
  return response.json();
};

export const deleteApiKey = async (id: string): Promise<void> => {
  await apiRequest('DELETE', `/api/api-keys/${id}`);
};
