import { useState } from "react";
import { useIsMobile } from "@/hooks/use-mobile";
import Sidebar from "@/components/sidebar";
import ChatInterface from "@/components/chat-interface";
import SettingsModal from "@/components/settings-modal";
import CreateCharacterModal from "@/components/create-character-modal";

export default function Home() {
  const [selectedCharacterId, setSelectedCharacterId] = useState<string>("einstein-1");
  const [currentConversationId, setCurrentConversationId] = useState<string | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isCreateCharacterOpen, setIsCreateCharacterOpen] = useState(false);
  const isMobile = useIsMobile();

  const handleCharacterSelect = (characterId: string, conversationId?: string) => {
    setSelectedCharacterId(characterId);
    setCurrentConversationId(conversationId || null);
    if (isMobile) {
      setIsSidebarOpen(false);
    }
  };

  const handleNewConversation = (conversationId: string) => {
    setCurrentConversationId(conversationId);
  };

  return (
    <div className="flex h-screen overflow-hidden bg-background text-foreground">
      {/* Mobile Overlay */}
      {isMobile && isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-10"
          onClick={() => setIsSidebarOpen(false)}
          data-testid="mobile-overlay"
        />
      )}

      {/* Sidebar */}
      <div className={`
        w-80 bg-card border-r border-border flex flex-col transition-all duration-300 ease-in-out
        ${isMobile ? 'absolute z-20 h-full' : 'relative'}
        ${isMobile && !isSidebarOpen ? '-translate-x-full' : 'translate-x-0'}
      `}>
        <Sidebar
          selectedCharacterId={selectedCharacterId}
          onCharacterSelect={handleCharacterSelect}
          onOpenSettings={() => setIsSettingsOpen(true)}
          onOpenCreateCharacter={() => setIsCreateCharacterOpen(true)}
          onCloseSidebar={() => setIsSidebarOpen(false)}
          isMobile={isMobile}
        />
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col bg-background">
        <ChatInterface
          characterId={selectedCharacterId}
          conversationId={currentConversationId}
          onNewConversation={handleNewConversation}
          onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
          isMobile={isMobile}
        />
      </div>

      {/* Modals */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
      />

      <CreateCharacterModal
        isOpen={isCreateCharacterOpen}
        onClose={() => setIsCreateCharacterOpen(false)}
        onCharacterCreated={(characterId) => {
          setSelectedCharacterId(characterId);
          setCurrentConversationId(null);
          setIsCreateCharacterOpen(false);
        }}
      />
    </div>
  );
}
