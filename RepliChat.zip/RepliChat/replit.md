# Overview

This is an AI Character Chat Application that allows users to have real-time conversations with AI-powered characters. Users can interact with pre-built characters or create their own custom characters, each with unique personalities, AI models, and voice synthesis capabilities. The application supports multiple AI providers (OpenAI, Gemini) and includes text-to-speech functionality via ElevenLabs integration.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React with TypeScript using Vite for development and build tooling
- **UI Library**: Radix UI components with custom shadcn/ui styling system
- **Styling**: Tailwind CSS with CSS variables for theming and dark mode support
- **State Management**: TanStack Query for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **Real-time Communication**: WebSocket integration for live chat functionality

## Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **WebSocket Server**: Built-in WebSocket support for real-time chat messaging
- **Session Management**: Express sessions with PostgreSQL session store
- **API Design**: RESTful endpoints with WebSocket enhancement for chat features

## Data Storage Solutions
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Database Provider**: Neon serverless PostgreSQL
- **Schema Management**: Drizzle Kit for migrations and schema management
- **In-Memory Fallback**: Memory storage implementation for development/testing

## Authentication and Authorization
- **User Management**: Username/password-based authentication
- **Session Storage**: PostgreSQL-backed sessions with connect-pg-simple
- **API Key Management**: Secure storage of third-party API keys per user

## AI Integration Architecture
- **Multi-Provider Support**: Pluggable AI service architecture supporting OpenAI and Google Gemini
- **Model Selection**: Per-character AI model configuration (GPT-5, Gemini 2.5 Flash)
- **Response Generation**: Character personality-driven prompt engineering
- **Service Abstraction**: Common interface for different AI providers

# External Dependencies

## AI Services
- **OpenAI API**: Primary AI provider using GPT-5 model for character conversations
- **Google Gemini API**: Alternative AI provider using Gemini 2.5 Flash model
- **Service Selection**: Per-character configuration allowing users to choose AI provider

## Voice Synthesis
- **ElevenLabs API**: Text-to-speech conversion for character responses
- **Voice Configuration**: Per-character voice selection from ElevenLabs voice library
- **Audio Streaming**: Real-time audio generation and playback

## Database Infrastructure
- **Neon Database**: Serverless PostgreSQL hosting with connection pooling
- **Database URL**: Environment variable-based connection configuration
- **Connection Management**: Automatic connection handling via Drizzle ORM

## Development Tools
- **Replit Integration**: Development environment optimizations and error handling
- **Vite Plugins**: Hot module replacement and development server enhancements
- **Build System**: ESBuild for server bundling and Vite for client bundling