import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, jsonb, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  isAdmin: boolean("is_admin").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const characters = pgTable("characters", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description").notNull(),
  personality: text("personality").notNull(),
  aiProvider: text("ai_provider").notNull(), // 'openai', 'gemini'
  model: text("model").notNull(),
  voiceId: text("voice_id"), // ElevenLabs voice ID
  avatarUrl: text("avatar_url"),
  isPublic: boolean("is_public").default(true),
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const conversations = pgTable("conversations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  characterId: varchar("character_id").references(() => characters.id).notNull(),
  title: text("title"),
  lastMessageAt: timestamp("last_message_at").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const messages = pgTable("messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  conversationId: varchar("conversation_id").references(() => conversations.id).notNull(),
  role: text("role").notNull(), // 'user' | 'assistant'
  content: text("content").notNull(),
  audioUrl: text("audio_url"), // ElevenLabs generated audio
  isVoiceMessage: boolean("is_voice_message").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const apiKeys = pgTable("api_keys", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  provider: text("provider").notNull(), // 'openai', 'gemini', 'elevenlabs'
  keyValue: text("key_value").notNull(),
  isActive: boolean("is_active").default(true),
  isGlobal: boolean("is_global").default(false), // Admin-only global keys
  createdAt: timestamp("created_at").defaultNow(),
});

export const voiceCalls = pgTable("voice_calls", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  conversationId: varchar("conversation_id").references(() => conversations.id).notNull(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  status: text("status").notNull().default("idle"), // 'idle', 'connecting', 'active', 'ended'
  startedAt: timestamp("started_at"),
  endedAt: timestamp("ended_at"),
  duration: varchar("duration"), // Duration in seconds
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertCharacterSchema = createInsertSchema(characters).pick({
  name: true,
  description: true,
  personality: true,
  aiProvider: true,
  model: true,
  voiceId: true,
  avatarUrl: true,
  isPublic: true,
}).extend({
  aiProvider: z.enum(['openai', 'gemini']),
});

export const insertConversationSchema = createInsertSchema(conversations).pick({
  characterId: true,
  title: true,
});

export const insertMessageSchema = createInsertSchema(messages).pick({
  conversationId: true,
  role: true,
  content: true,
}).extend({
  role: z.enum(['user', 'assistant']),
});

export const insertApiKeySchema = createInsertSchema(apiKeys).pick({
  provider: true,
  keyValue: true,
  isGlobal: true,
}).extend({
  provider: z.enum(['openai', 'gemini', 'elevenlabs']),
});

export const insertVoiceCallSchema = createInsertSchema(voiceCalls).pick({
  conversationId: true,
  status: true,
});

export const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Character = typeof characters.$inferSelect;
export type InsertCharacter = z.infer<typeof insertCharacterSchema>;

export type Conversation = typeof conversations.$inferSelect;
export type InsertConversation = z.infer<typeof insertConversationSchema>;

export type Message = typeof messages.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;

export type ApiKey = typeof apiKeys.$inferSelect;
export type InsertApiKey = z.infer<typeof insertApiKeySchema>;

export type VoiceCall = typeof voiceCalls.$inferSelect;
export type InsertVoiceCall = z.infer<typeof insertVoiceCallSchema>;

export type LoginRequest = z.infer<typeof loginSchema>;
